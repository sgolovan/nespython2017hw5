# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 09:21:21 2018

@author: Ruslan Safiullin
"""

import seaborn as sns
from mpl_toolkits.basemap import Basemap
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import requests
import csv
import re
import zipfile
import os


#%% Ex 1.1
##unzipping  file using url link
r = requests.get('https://drive.google.com/uc?export=download&id=0B6ZlG_Eygdj-c1kzcmUxN05VUXM')
with open('Directory.zip', 'wb') as code:
    code.write(r.content)
path = os.getcwd() + '/Directory.zip'
zip_ref = zipfile.ZipFile(path, 'r')
zip_ref.extractall(os.getcwd())
zip_ref.close()

#%% show first columns top lines
data = pd.DataFrame.from_csv(path='survey_results_public.csv', sep = ',', header=0, encoding='utf-8')
data.iloc[:,:1].head()
#%%
schema = pd.DataFrame.from_csv(path='survey_results_schema.csv', sep = ',', header=0, encoding='utf-8')
schema.head()
#%% Ex 1.2

##defining map properties and coordinates for Europe
plt.figure(figsize = (25,25))
coord = {'left_lon': -180,'right_lon': 180, 'left_lat': -90, 'right_lat': 90 }
m = Basemap(projection='cyl',llcrnrlat=coord['left_lat'],
            urcrnrlat=coord['right_lat'],
            llcrnrlon=coord['left_lon'], urcrnrlon=coord['right_lon'],resolution='c')
##defining properties of boundaries
m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False)
m.fillcontinents(color='peru',lake_color='aqua')

m.drawmapboundary(fill_color='aqua')
##show graph with title
plt.title("World map\n", fontsize=18)
plt.show()

#%% Ex 1.3

#importing data

CSV_URL = 'https://developers.google.com/public-data/docs/canonical/countries_csv'
d = pd.read_html(CSV_URL, index_col = 0)[0]
d = d.drop(d[(d[1] == 'latitude')].index)
#deliation af data and assigning format
d[1] = d[1].astype(float)
d[2] = d[2].astype(float)
d = d.dropna()   #dropping NA fields
d3 = d  #creating new as a buffer
#creating d3 using dictionaries
d3.rename(columns = {0 : 'name',1 : 'latitude',2: 'longtitude', 3 : 'Country'}, inplace = True)
#creating cylindrical map 
plt.figure(figsize = (25,25)) ##defining size
coord = {'left_lon': -180,'right_lon': 180, 'left_lat': -90, 'right_lat': 90 } ##europe coordinates
m = Basemap(projection='cyl',llcrnrlat=coord['left_lat'],
            urcrnrlat=coord['right_lat'],
            llcrnrlon=coord['left_lon'], urcrnrlon=coord['right_lon'],resolution='c')  ##masemap creation
##difining properties for map
m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False)
m.fillcontinents(color='peru',lake_color='aqua')
#colouring boundaries
m.drawmapboundary(fill_color='aqua')

##restricting size of map to create within required size
d = d[(coord['left_lat'] <= d[1]) & (d[1] <= coord['right_lat']) & (coord['left_lon'] <= d[2]) & (d[2] <= coord['right_lon'])]

x1, y1 = m(d[2], d[1])

# draw as a scatter on a top layer zorder=10
m.scatter(x1, y1, marker='o', color='red', s = 100, zorder=10)
#plotting names
for i in range(d.shape[0]):
    plt.text(x1.iloc[i]-6, y1.iloc[i]-2, d.iloc[i][3], fontsize=15)
    
# Plotting countries 
plt.title("Countries\n", fontsize=18)
plt.show()

#%% Ex 1.4
##defining masemap properties
plt.figure(figsize = (25,25))
coord = {'left_lon': -180,'right_lon': 180, 'left_lat': -90, 'right_lat': 90 }
m = Basemap(projection='cyl',llcrnrlat=coord['left_lat'],
            urcrnrlat=coord['right_lat'],
            llcrnrlon=coord['left_lon'], urcrnrlon=coord['right_lon'],resolution='c')
##difining properties for map
m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False)
m.fillcontinents(color='peru',lake_color='aqua')
#colouring boundaries
m.drawmapboundary(fill_color='aqua')
##restricting size of map to create within required size
d = d[(coord['left_lat'] <= d[1]) & (d[1] <= coord['right_lat']) & (coord['left_lon'] <= d[2]) & (d[2] <= coord['right_lon'])]

#sorting key by ascending of numbers of respondents
num = data.groupby(['Country']).count().sort_values(['Respondent'], ascending = False)['Respondent']
Numb = pd.DataFrame({'Country' : num.index, 'Total' : num.values}, index = None)
#merging dataframes 
s1 = pd.merge(d3, Numb, how='inner', on=['Country'])
#defining coordinates
x1, y1 = m(s1['longtitude'], s1['latitude'])

#scattering adding size to third argument (s)with rescaling size(too big size)
m.scatter(x1, y1, marker='o', color='red', s = s1['Total'] / 20, zorder=10)
##plotting within coordinates
for i in range(s1.shape[0]):
    plt.text(x1.iloc[i]-6, y1.iloc[i]-5, s1.iloc[i]['Country'], fontsize=15)
    
# fontsize - шрифты
##show plot 
plt.title("Countries\n", fontsize=18)
plt.show()

#%% Ex2.1
#unzipping file
zf = zipfile.ZipFile('railways.zip')  ## in home directory
zf.namelist()
zf.extractall(os.getcwd())
zf.close()

#%%  #creation of dataframe with railways
railways = pd.DataFrame.from_csv(path='railways201208.csv', sep = ',', header = 0, index_col = 1, encoding='utf-8')

#%% #show head for required keys 
railways[['date_priem', 'sto_code', 'stn_code', 'dist']].head()
#%%   #creation of dataframe with stations
stations = pd.DataFrame.from_csv(path='stations.csv', sep = ',', header=0, index_col = 1, encoding='utf-8')
#%% show head as in example 
stations[['stshortname',  'stcode']].head()
#%% Ex 2.2
#taking log for distance
railways['log_dist'] = np.log(railways['dist'])
##using seaborn we create a hystogram
sns.distplot(railways['log_dist'],bins=np.linspace(0 , 10 , 100) , kde_kws = {'color' : 'limegreen' ,'label': 'log Distance'}, hist_kws = {'color':'royalblue', 'alpha':None}, axlabel = '$log(Distance)$')


#%% Ex2.3

box = pd.DataFrame() ##creating box wothin pandas class
box['Coal'] = railways[railways['commodity'] == 1]['log_dist']  ## defing first commodity to conacatenate in cycle
for i in range(2,11):   ##
    box = pd.concat([box, railways[railways['commodity'] == i]['log_dist']], axis = 0, ignore_index = True)
    box.rename(columns = {'Coal' : 'Coal' , 0 : i}, inplace = True)
#creation of axes
ax = plt.axes()
##creating of boxplot
sns.boxplot(box, ax = ax)
ax.set_xlabel('Commodity type')  #setting labels
ax.set_ylabel('log Distance',  family = 'cursive')
##naming ticks
ax.set_xticklabels( ['Coal', 'Oil', 'Ores', 'Metals', 'Wood', 'Constructions','Fertilizers' , 'Grains' , 'Petrol', 'Others'], rotation = 90 )
plt.show()
#%% Ex 2.4
##creating dataframe for 3 column
box = pd.DataFrame(columns = ['Commodity type', 'log Distance', 'Weight'])
##replacing commodity nums with names
box['Commodity type'] = railways['commodity'].replace(to_replace = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], value = ['Coal', 'Oil', 'Ores', 'Metals', 'Woods', 'Constructions', 'Fertilizers', 'Grains','Petrol', 'Others'])
#makeing kopy for log_dist
box['log Distance'] = railways['log_dist']

l = pd.DataFrame() ##new empty dataframe
l['dummy'] = railways['weight'] < railways['weight'].median() #soorting using boolean for median
l = l.replace(to_replace=[True, False], value=['Light', 'Heavy']) #for sorted types assign new names according to boolean

box['Weight'] = l
##making violinplot
ax = plt.axes()
sns.violinplot(data = box, x = 'Commodity type', y = 'log Distance', hue = 'Weight', split = True, order = ['Coal', 'Oil', 'Ores', 'Metals', 'Woods', 'Constructions', 'Fertilizers' , 'Grains' , 'Petrol', 'Others'], ax = ax, hue_order= ['Light', 'Heavy'])
ax.set_xticklabels( ['Coal', 'Oil', 'Ores', 'Metals', 'Wood', 'Constructions', 'Fertilizers' , 'Grains' , 'Petrol', 'Others'], rotation = 90 )
plt.show()

#%%  Ex 2.5

##drop statistically insignificant values
railways.drop(railways[railways['amount'] == 0].index, inplace = True)
#taing logarithm
railways['log_amount'] = np.log(railways['amount'])
#finding product
railways['product'] = np.log(railways['weight'] * railways['dist'])
#creation of jointplots
g = sns.jointplot(x='product', y='log_amount', data = railways, kind = 'reg', marginal_kws={'hist_kws': {'edgecolor': "black"}})#kind можно прописывать разным. Например, 'hex', 'kde'
##setting size
g.fig.set_figwidth(10)
g.fig.set_figheight(10)
#defining axis labels
g.set_axis_labels("$log(weight*dist)$", "$log(amount)$");
plt.show()