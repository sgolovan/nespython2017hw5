#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 00:31:31 2018

@author: apolyakov
"""
#%%
import re
import requests

import matplotlib.pylab as plt
import numpy as np
import pandas as pd
import zipfile

pd.set_option('float_format', '{:6.2f}'.format)
np.set_printoptions(precision=3, suppress=True)

url = 'https://drive.google.com/uc?export= download&id=0B6ZlG_Eygdj-c1kzcmUxN05VUXM'
path = '/Users/alenasemanina/Desktop/NES/mod3/python/data/hw5_data.zip'
#%%
#task_1
response = requests.get(url)
with open(path, "wb") as file:
    file.write(response.content)
#%%
zf = zipfile.ZipFile(path)
files = zf.namelist()

print(files)
#%%
#Load data into pandas DataFrame. Print datatypes.

public = pd.read_csv(zf.open(files[-2]))
public.columns = [x.strip() for x in public.columns]

schema = pd.read_csv(zf.open(files[-1]))
schema.columns = [x.strip() for x in schema.columns]
#%%
print('Number of questions', schema.iloc[1:,:].shape[0], '\nNumber of respondents', public.iloc[:,:2].shape[0] )
#%%
from mpl_toolkits.basemap import Basemap
#%%

plt.figure(figsize = (18,25))
m = Basemap(projection='cyl',llcrnrlat=-90,urcrnrlat=90,
            llcrnrlon=-180,urcrnrlon=180,resolution='c')
m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False) #antialiased - отвечает за прозрачность линий
#color = цвет континентов, lake_color = цвет озер
m.fillcontinents(color='chocolate',lake_color='aqua')
m.drawparallels(np.arange(-90.,90, 30.))
m.drawmeridians(np.arange(-180.,181.,60.))
m.drawmapboundary(fill_color='aqua') # draw a line around the map region
plt.title("Cylindrical Equal-Area Projection")
plt.savefig('/Users/alenasemanina/Desktop/picture1.pdf')
plt.show()
#%%
url1 = 'https://developers.google.com/public-data/docs/canonical/countries_csv'
#%%
coord_raw = pd.read_html(url1, header = 0)
coord = coord_raw[0]
#%%
plt.figure(figsize = (18,25))
m = Basemap(projection='cyl',llcrnrlat=-90,urcrnrlat=90,
            llcrnrlon=-180,urcrnrlon=180,resolution='c')
m.drawcoastlines()
#m.drawcountries(linewidth=0.25, antialiased = False) #antialiased - отвечает за прозрачность линий
#color = цвет континентов, lake_color = цвет озер
m.fillcontinents(color='PINK',lake_color='aqua')
m.drawparallels(np.arange(-90.,90, 30.))
m.drawmeridians(np.arange(-180.,181.,60.))
m.drawmapboundary(fill_color='aqua') # draw a line around the map region
plt.title("with country markers")


y = coord['latitude']
x = coord['longitude']
m.scatter(x, y, marker='D', color='m', s = 100, zorder=10)

for i in range(6,13):
    plt.text(x.iloc[i]-6, y.iloc[i]-10, coord.iloc[i]['name'], fontsize=15)
plt.savefig('/Users/alenasemanina/Desktop/picture2.pdf')
plt.show()
#%%
plt.figure(figsize = (18,25))
m = Basemap(projection='cyl',llcrnrlat=-90,urcrnrlat=90,
            llcrnrlon=-180,urcrnrlon=180,resolution='c')
m.drawcoastlines()
#m.drawcountries(linewidth=0.25, antialiased = False) #antialiased - отвечает за прозрачность линий
#color = цвет континентов, lake_color = цвет озер
m.fillcontinents(color='PINK',lake_color='aqua')
m.drawparallels(np.arange(-90.,90, 30.))
m.drawmeridians(np.arange(-180.,181.,60.))
m.drawmapboundary(fill_color='aqua') # draw a line around the map region
plt.title("with country markers")


y = coord['latitude']
x = coord['longitude']
m.scatter(x, y, marker='D', color='m', s = 100, zorder=10)
#plt.text(x-6, y-10, coord['name'], fontsize=15)
plt.savefig('/Users/alenasemanina/Desktop/picture3.pdf')
plt.show()
#%%
dict = {'Bosnia-Herzegovina': 'Bosnia and Herzegovina',
'Azerbaidjan': 'Azerbaijan',
'Brunei Darussalam': 'Brunei',
'Falkland Islands': 'Falkland Islands [Islas Malvinas]',
'Heard and McDonald Islands': 'Heard Island and McDonald Islands',
'Slovak Republic': 'Slovakia',
'Tadjikistan': 'Tajikistan',
'Vatican City State': 'Vatican City',
'Virgin Islands (British)': 'British Virgin Islands',
'Virgin Islands (USA)': 'U.S. Virgin Islands',
'Russian Federation': 'Russia',
'Polynesia (French)': 'French Polynesia',
'Pitcairn Island': 'Pitcairn Islands',
'Saint Vincent & Grenadines': 'Saint Vincent and the Grenadines',
'Reunion (French)': 'Réunion',
'Ivory Coast (Cote D\'Ivoire)': 'Côte d\'Ivoire',
'Zaire': 'Congo [DRC]',
'Macedonia': 'Macedonia [FYROM]',
'Martinique (French)': 'Martinique',
'Myanmar': 'Myanmar [Burma]',
'New Caledonia (French)': 'New Caledonia',
'S. Georgia & S. Sandwich Isls.':
'South Georgia and the South Sandwich Islands',
'Moldavia': 'Moldova',
'French Guyana': 'French Guiana',}
#%%
public_country_rename = public['Country'].replace(dict, inplace = True) 
#%%
public_country = public.groupby('Country').count()
resp_country = public_country['Respondent']
#%% Here we want to make countries to be index of coord
coord_country = coord.set_index('name')
#%%
#we have coord and public country where index is country name
merged = pd.concat([resp_country, coord_country], axis=1, join_axes=[public_country.index]).dropna()
#%% normalizing of respondent number to draw it.

merged_norm = merged
merged_norm['Respondent'] = (merged_norm['Respondent']/merged['Respondent'].max())*1000

#%%
plt.figure(figsize = (18,25))
m = Basemap(projection='cyl',llcrnrlat=-90,urcrnrlat=90,
            llcrnrlon=-180,urcrnrlon=180,resolution='c')
m.drawcoastlines()
#m.drawcountries(linewidth=0.25, antialiased = False) #antialiased - отвечает за прозрачность линий
#color = цвет континентов, lake_color = цвет озер
m.fillcontinents(color='PINK',lake_color='aqua')
m.drawparallels(np.arange(-90.,90, 30.))
m.drawmeridians(np.arange(-180.,181.,60.))
m.drawmapboundary(fill_color='aqua') # draw a line around the map region
plt.title("with country markers")


y1 = merged_norm['latitude']
x1 = merged_norm['longitude']

for i in range(0, x1.shape[0]):
   m.scatter(x1.iloc[i], y1.iloc[i], marker='o', color='m', s = merged_norm.iloc[i,0], zorder=10) 
   if  merged_norm.iloc[i,0] > 300:
       plt.text(x1.iloc[i]-6, y1.iloc[i]-10, merged_norm.index[i], fontsize=15)
plt.savefig('/Users/alenasemanina/Desktop/picture4.pdf')
plt.show()
    #%% task 2
railways = pd.read_csv('/Users/alenasemanina/Desktop/NES/mod3/python/data/railways/railways201208.csv')
railways.columns = [x.strip() for x in railways.columns]

stations = pd.read_csv('/Users/alenasemanina/Desktop/NES/mod3/python/data/railways/stations.csv')
stations.columns = [x.strip() for x in stations.columns]
#%%
railways['log_dist'] = railways['dist'].apply(lambda x: np.log(1 + x))
#%%
import seaborn as sns
#%%
plt.hist(railways['log_dist'],100, normed=True)
sns.kdeplot(railways['log_dist'], shade=True)
plt.xlabel('logarifm dist')
plt.savefig('/Users/alenasemanina/Desktop/picture5.pdf')
plt.show()
#%%
plt.hist(railways['dist'],100, normed=True)
sns.kdeplot(railways['dist'], shade=True)
plt.xlabel('dist')
plt.savefig('/Users/alenasemanina/Desktop/picture5.pdf')
plt.show()
#%%
dict1 = {1:'уголь', 2:'сырая_нефть', 3: 'руды_металлические', 
        4: 'металлургическая_продукция', 5: 'лесная_продукция', 
        6 : 'строительные_материалы', 7 : 'удобрения', 8 : 'зерно_и_продукты_перемола', 
        9 : 'продукты_нефтепереработки', 10: 'остальные_грузы'}

railways['commodity'].replace(dict1, inplace = True) 
#%%
#plt.figure(figsize=(10, 25))
sns.boxplot(x='commodity', y='log_dist', data=railways)
plt.xticks(rotation=90)
plt.savefig('/Users/alenasemanina/Desktop/picture5.pdf')
plt.show()
#%%
median =  railways.groupby('commodity').median()
#%%
def f(x):
    for i in range (0, median.shape[0]):
        if x['commodity'] == median.index[i]:
            if x['weight'] > median['weight'][0]:
                return 'weighty'
            else:
                return 'light'
#%%
railways['compare'] = railways[['commodity', 'weight']].apply(f, axis=1)
#%%
plt.figure(figsize=(8, 8))
sns.violinplot(x='commodity', y='log_dist',
               hue='compare', split=True,
               linewidth=.5, data=railways)
plt.xticks(rotation='vertical')
plt.savefig('/Users/alenasemanina/Desktop/picture5.pdf')
plt.show()
#%%
railways['log_weight'] = railways['weight'].apply(lambda x: np.log(1 + x))
railways['log_sum'] = railways['log_weight'] + railways['log_dist'] 

railways['log_amount'] = railways['amount'].apply(lambda x: np.log(1 + x))
#%%
railways_sort = railways[['log_sum','log_amount','amount']]
#railways_sort = railways_sort.
#%%
for i in range(0,railways_sort.shape[0]):
    if railways_sort.iloc[i,2] == 0:
        print(railways_sort.index[i],railways_sort.iloc[i,0])
print(railways_sort['log_sum'].mean(),railways_sort['log_sum'].median())
#%%
#railways_sort = railways_sort[pd.(railways_sort['amount'] == 0)]
railways_sort1 = railways_sort[railways_sort['amount'] != 0]
#%%
sns.jointplot(x='log_sum', y='log_amount',
              data=railways_sort1.sample(2000), size=6, kind='reg')
plt.savefig('/Users/alenasemanina/Desktop/picture3.pdf')
plt.show()












